let tab = []
function aleatoires(){
    for(i=0; i <= 999; i++){
       tab[i] = Math.random()
    }
   }
  aleatoires()
   